#include "call.h"
#include <stdio.h>

int main(){
    char filename[MAX_COMMAND_LENGTH] = "/dir2/dir7/dir12/file1";
    char *buf = (char*)malloc(MAX_FILE_SIZE);
    int test_inode=open_t(filename);
    int offsets[] = {0,4096,10240,43690,15,100,16484,1239031,1239131,10};
    int counts[] = {100,1000,300,800,5000,50000,60000,10000,10,1000000};
    int expected[] = {100,1000,300,800,5000,50000,60000,50,0,1000000};

    for(int i = 0; i < sizeof(offsets) / sizeof(offsets[0]); i++){   //modified
        int off = offsets[i];
        int cnt = counts[i];
        printf("====case %d: read %d bytes from %d offest=======\n", i, cnt, off);
        int read_sz = read_t(test_inode, off, buf, cnt);
        buf[read_sz] = '\0';
        printf("read size: %d	 expected: %d\n\n", read_sz, expected[i]);
        printf("read bytes: %s\n\n", buf);
    }

    return 0;
}
