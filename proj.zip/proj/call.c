#include "call.h"
#include "inode.h"     
#include "superblock.h" 
const char *HD = "HD";
static int HD_fd = -1;  // Global fd

inode* read_inode(int fd, int inode_number);
void init_file_system();
int scan_dir_block(int fd, int blk_num, char *target_name);
int read_data_block(int fd, int blk_num, int file_offset, void *buf, int count);
int read_indirect_block(int fd, int indirect_blk_num, int start_index, void *buf, int count);

int open_t(char *pathname)
{
	// TODO: implement this function
	init_file_system(); // initialize HD_fd
	if(pathname == NULL) {
		return -1; // invalid pathname
	}

	char pathname_copy[MAX_COMMAND_LENGTH];
	strncpy(pathname_copy, pathname, MAX_COMMAND_LENGTH); //vector to array
	pathname_copy[MAX_COMMAND_LENGTH - 1] = '\0'; // null-termination

	char *token[128];
	int token_count = 0;

	char *ptr = pathname_copy;
	if (*ptr == '/') ptr++;  // Skip leading '/'

	ptr = strtok(ptr, "/");
	while (ptr != NULL) {
    	token[token_count++] = ptr;
    	ptr = strtok(NULL, "/");
	}

	if(token_count == 0) {
		return 0; // root directory
	}

    int current_inum = 0;
    inode *root_inode = read_inode(HD_fd, current_inum);
    if (root_inode == NULL || root_inode->f_type != DIR) {
        free(root_inode);
        return -1;
    }
    free(root_inode);


    for (int i = 0; i < token_count; i++) {
        inode *dir_inode = read_inode(HD_fd, current_inum);
        if (dir_inode == NULL || dir_inode->f_type != DIR) {
            free(dir_inode);
            return -1;
        }

        int found_inum = -1;
        for (int j = 0; j < 2 && found_inum < 0; j++) {
            if (dir_inode->direct_blk[j] != 0) {
                found_inum = scan_dir_block(HD_fd, dir_inode->direct_blk[j], token[i]);
            }
        }
        if (found_inum < 0 && dir_inode->indirect_blk != 0) {
            found_inum = scan_dir_block(HD_fd, dir_inode->indirect_blk, token[i]);
        }
        free(dir_inode);

        if (found_inum < 0) return -1;
        
        if (i < token_count - 1) {
            inode *next_inode = read_inode(HD_fd, found_inum);
            if (next_inode == NULL || next_inode->f_type != DIR) {
                free(next_inode);
                return -1;
            }
            free(next_inode);
        }
        current_inum = found_inum;
    }
    return current_inum;
}


int read_t(int i_number, int offset, void *buf, int count)
{
	// TODO: implement this function
	inode *file_inode = read_inode(HD_fd, i_number);
	/*printf("DEBUG: inode direct_blk[0]=%d, direct_blk[1]=%d, indirect_blk=%d, f_size=%d\n", 
           file_inode->direct_blk[0], file_inode->direct_blk[1], file_inode->indirect_blk, file_inode->f_size);*/
	if(file_inode == NULL || file_inode->f_type != FILE) {
		free(file_inode);
		return -1; // invalid parameters
	}

	int bytes_left = file_inode->f_size - offset;
	if(bytes_left <= 0) {
		free(file_inode);
		return 0; // EOF
	}

	int bytes_to_read = (count < bytes_left) ? count : bytes_left;
	int total_read = 0;
	char *buf_ptr = (char*)buf;
	int cur_offset = offset;

	//direct blocks
    while (bytes_to_read > 0) {
        int block_index = cur_offset / BLK_SIZE;    // which logical block of file
        int block_offset = cur_offset % BLK_SIZE;   // inside that block

        int blk_num = -1;
        if (block_index < 2) {
            blk_num = file_inode->direct_blk[block_index];
        } else {
            // Move into indirect blocks
            blk_num = read_indirect_block(HD_fd, file_inode->indirect_blk, block_index - 2, NULL, 0);
        }

        if (blk_num <= 0) break; // no such block

        int bytes = read_data_block(HD_fd, blk_num, block_offset, buf_ptr, bytes_to_read);
        if (bytes <= 0) break;

        total_read += bytes;
        bytes_to_read -= bytes;
        cur_offset += bytes;
        buf_ptr += bytes;
    }

    free(file_inode);
    return total_read;
}

// you are allowed to create any auxiliary functions that can help your implementation. But only "open_t()" and "read_t()" are allowed to call these auxiliary functions.
inode* read_inode(int fd, int inode_number) {
    inode *ip = (inode*)malloc(sizeof(inode));
    if (ip == NULL) return NULL;
    
    long long offset = I_OFFSET + (long long)inode_number * sizeof(inode);
    lseek(fd, offset, SEEK_SET);
    
    int bytes = read(fd, ip, sizeof(inode));
    if (bytes != sizeof(inode)) {
        free(ip);
        return NULL;
    }
    
    return ip;
}

void init_file_system() {
    if (HD_fd < 0) {
        HD_fd = open(HD, O_RDWR);
        if (HD_fd < 0) {
            perror("open HD");
        }
    }
}

int scan_dir_block(int fd, int blk_num, char *target_name) {
    DIR_NODE entries[MAX_BLOCK_NUMBER_PER_BLOCK];
    int offset = D_OFFSET + (long long)blk_num * BLK_SIZE;
    lseek(fd, offset, SEEK_SET);
    int bytes = read(fd, entries, BLK_SIZE);
    if (bytes != BLK_SIZE) return -1;
    
    for (int i = 0; i < bytes / (int)sizeof(DIR_NODE); i++) {
        if (strcmp(entries[i].f_name, target_name) == 0) {
            return entries[i].i_number;
        }
    }
    return -1;
}

int read_data_block(int fd, int blk_num, int file_offset, void *buf, int count) {
    int block_offset = file_offset % BLK_SIZE;
    int bytes_in_block = BLK_SIZE - block_offset;
    int bytes_to_read = (count < bytes_in_block) ? count : bytes_in_block;
    
    long long disk_offset = D_OFFSET + (long long)blk_num * BLK_SIZE + block_offset;
    lseek(fd, disk_offset, SEEK_SET);
    return read(fd, buf, bytes_to_read);
}

int read_indirect_block(int fd, int indirect_blk_num, int start_index, void *buf, int count)
{
    if(indirect_blk_num == 0) return 0;

    int block_ptrs[MAX_BLOCK_NUMBER_PER_BLOCK];
    long long offset = D_OFFSET + (long long)indirect_blk_num * BLK_SIZE;

    if (lseek(fd, offset, SEEK_SET) < 0) return 0;
    int bytes = read(fd, block_ptrs, BLK_SIZE);
    if (bytes != BLK_SIZE) return 0;

    // Lookup mode: return block number directly
    if (buf == NULL && count == 0) {
        if (start_index < 0 || start_index >= (int)MAX_BLOCK_NUMBER_PER_BLOCK)
            return 0;
        return block_ptrs[start_index];
    }

    // Otherwise, perform reading across multiple data blocks
    int total_read = 0;
    char *buf_ptr = (char*)buf;
    int blk_idx = start_index; // start index in the indirect block table

    while (blk_idx < (int)MAX_BLOCK_NUMBER_PER_BLOCK && count > 0) {
        int blk = block_ptrs[blk_idx];
        if (blk == 0) break;

        int bytes_read = read_data_block(fd, blk, (blk_idx == start_index) ? 0 : 0, buf_ptr, count);
        if (bytes_read <= 0) break;

        buf_ptr += bytes_read;
        total_read += bytes_read;
        count -= bytes_read;
        blk_idx++;
    }

    return total_read;
}