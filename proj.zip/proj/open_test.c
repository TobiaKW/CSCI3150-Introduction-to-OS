#include "call.h"
#include <stdio.h>

int main(){
    struct { const char* path; int expected; } cases[] = {
        {"/", 0},
        {"/dir1", 1},
        {"/dir2", 2},
        {"/dir3", 3},
        {"/dir1/dir4", 4},
        {"/dir1/dir5", 5},
        {"/dir1/dir6", 6},
        {"/dir1/dir4/dir12", 7},
        {"/dir1/dir4/dir12/file2", 8},
        {"/dir1/dir6/dir11", 9},
        {"/dir1/dir6/dir12", 10},
        {"/dir1/dir6/dir11/file3", 11},
        {"/dir1/dir6/dir12/file2", 12},
        {"/dir1/dir6/dir12/file5", 13},
        {"/dir2/dir7", 14},
        {"/dir2/dir8", 15},
        {"/dir2/dir7/dir12", 16},
        {"/dir2/dir7/file4", 17},
        {"/dir2/dir7/dir12/file1", 18},
        {"/dir3/dir8", 19},
        {"/dir3/dir8/dir1", 20},
        {"/dir3/dir8/dir12", 21},
        {"/dir3/dir8/dir1/file7", 22},
        {"/dir3/dir8/dir12/file6", 23},
        {"/dir3/dir8/dir12/./file6", 23},
        {"/dir3/dir8/dir12/../dir1", 20},
    };

    int ok=0, total = sizeof(cases) / sizeof(cases[0]);
    for(int i = 0; i < total; i++){
        int ino=open_t((char*)cases[i].path);
        printf("open '%s' => %d (expected %d)\n", cases[i].path, ino, cases[i].expected);
        if(ino == cases[i].expected) ok++;
    }

    printf("%d/%d passed\n", ok, total);
    return ok == total ? 0 : 1;
}
